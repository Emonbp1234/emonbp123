# Hotel-Management-System
Use of HTML, CSS , jQuery , JavaScript,BootStrap
